module.exports = {
    MONGODB_USERNAME: "melanatedpeopleinc", //mongoDb string
    MONGODB_PASSWORD: "Q3ZinT5njs9n9",  //mongo password
    MONGODB_DB_NAME: "moyoodb",  //project name
    MONGODB_CONNECTION_STRING : "mongodb+srv://melanatedpeopleinc:Q3ZinT5njs9n9@moyoodb.8pwfnh3.mongodb.net/",

    //port
    PORT: process.env.PORT || 5000,
  
    //secret key for API
    SECRET_KEY: "your_secret_key",
  
    //secret key for jwt
    JWT_SECRET: "DYMokDFXXg",
  
    baseURL: "http://localhost:5000/",
  
    SERVER_KEY: "AAAAfSSyJck:APA91bFZjPBz_8lZ1WuJlp10eqAHv4cauRN6l00UAXFK2k3KiugXYHf7F8i4UAeuTzLjarvjj6G66oGBB6SLVQzGkEy0EmbjzqQyA4OykfaT76otcLugMf1xXXjCbpddTcTPpuRrRsJt",
  };